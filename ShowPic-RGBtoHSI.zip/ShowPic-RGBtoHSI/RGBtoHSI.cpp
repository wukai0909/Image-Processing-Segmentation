// RGBtoHSI.cpp : implementation file
//

#include "stdafx.h"
#include "ShowPic.h"
#include "RGBtoHSI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRGBtoHSI dialog


CRGBtoHSI::CRGBtoHSI(CWnd* pParent /*=NULL*/)
	: CDialog(CRGBtoHSI::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRGBtoHSI)
	m_huemax = 0;
	m_huemax2 = 0;
	m_huemin = 0;
	m_huemin2 = 0;
	m_intensitymax = 0;
	m_intensitymin = 0;
	m_saturationmax = 0;
	m_saturationmin = 0;
	//}}AFX_DATA_INIT
}


void CRGBtoHSI::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRGBtoHSI)
	DDX_Text(pDX, IDC_huemax, m_huemax);
	DDV_MinMaxInt(pDX, m_huemax, 0, 360);
	DDX_Text(pDX, IDC_huemax2, m_huemax2);
	DDV_MinMaxInt(pDX, m_huemax2, 0, 360);
	DDX_Text(pDX, IDC_huemin, m_huemin);
	DDV_MinMaxInt(pDX, m_huemin, 0, 360);
	DDX_Text(pDX, IDC_huemin2, m_huemin2);
	DDV_MinMaxInt(pDX, m_huemin2, 0, 360);
	DDX_Text(pDX, IDC_intensitymax, m_intensitymax);
	DDV_MinMaxInt(pDX, m_intensitymax, 0, 255);
	DDX_Text(pDX, IDC_intensitymin, m_intensitymin);
	DDV_MinMaxInt(pDX, m_intensitymin, 0, 255);
	DDX_Text(pDX, IDC_saturationmax, m_saturationmax);
	DDV_MinMaxInt(pDX, m_saturationmax, 0, 100);
	DDX_Text(pDX, IDC_saturationmin, m_saturationmin);
	DDV_MinMaxInt(pDX, m_saturationmin, 0, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRGBtoHSI, CDialog)
	//{{AFX_MSG_MAP(CRGBtoHSI)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRGBtoHSI message handlers
